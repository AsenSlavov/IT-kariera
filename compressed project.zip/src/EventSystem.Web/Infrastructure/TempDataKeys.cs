namespace EventSystem.Web.Infrastructure;

public static class TempDataKeys
{
    public const string Success = "SuccessMessage";
    public const string Error = "ErrorMessage";
}
